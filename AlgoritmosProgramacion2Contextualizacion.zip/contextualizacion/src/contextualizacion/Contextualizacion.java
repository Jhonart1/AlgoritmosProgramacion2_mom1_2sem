
package contextualizacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * @author jhona
 */
public class Contextualizacion extends JFrame{
    public static void main(String[] args) {

        JButton boton = new JButton("Hola");
        VistaSegunda vista = new VistaSegunda();
        vista.iniciarVentana();
        //eventos
        ActionListener calcular = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vista.panelCalcular();
            }
        };
        vista.getBoton().addActionListener(calcular);
    }

}
