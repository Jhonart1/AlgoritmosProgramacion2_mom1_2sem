package contextualizacion;

import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class VistaSegunda extends JFrame {
    //etiquetas
    JLabel nombreCal = new JLabel();
    JLabel cedulaCal = new JLabel();
    JLabel salarioCal = new JLabel();
    JLabel ventasCal = new JLabel();
    JLabel subCal = new JLabel();
    JLabel totalCal = new JLabel();
    JLabel nombre = new JLabel("Nombre");
    JLabel cedula = new JLabel("Cedula");
    JLabel salario = new JLabel("Salario");
    JLabel ventas = new JLabel("Ventas");
    //paneles
    JPanel panel = new JPanel();
    JPanel panel2 = new JPanel();
    //cajas de texto
    JTextField nombreCaja = new JTextField();
    JTextField cedulaCaja = new JTextField();
    JTextField salarioCaja = new JTextField();
    JTextField ventasCaja = new JTextField();
    //botones
    JButton boton = new JButton("Calcular Salario");

    public void iniciarVentana() {
        setSize(400, 220);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        //paneles
        this.getContentPane().add(panel);
        panel.setBounds(0, 0, 400, 180);
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
        etiquetas();
        cajas();
        botones();
    }

    public void panelCalcular() {
        setSize(400,400);
        //variables
        String nombre = nombreCaja.getText();
        String cedula = cedulaCaja.getText();
        String salario = salarioCaja.getText();
        String ventas = ventasCaja.getText();
        int total = 0;
        int subsidioTrans = 140000;
        //panel config
        add(panel2);
        panel2.setBounds(0, 180, 400, 180);
        panel2.setLayout(null);
        //etiquetas se añaden al oprimir boton calcular
        nombreCal.setText("Empleado: " + nombre);
        nombreCal.setBounds(20, 10, 300, 20);
        nombreCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel2.add(nombreCal);
        cedulaCal.setText("Cedula: " + cedula);
        cedulaCal.setBounds(20, 30, 300, 20);
        cedulaCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel2.add(cedulaCal);
        salarioCal.setText("Salario Basico: $" + salario);
        salarioCal.setBounds(20, 50, 300, 20);
        salarioCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel2.add(salarioCal);
        total = total + Integer.parseInt(salario);
        //comisiones
        if (Integer.parseInt(ventas) >= 500000){ //si ventas es mayor a 500 mil
            int comisiones = Integer.parseInt(ventas)*10/100;
            ventasCal.setText("Comisiones 10% de ventas: $" + comisiones);
            ventasCal.setBounds(20, 70, 300, 20);
            ventasCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            panel2.add(ventasCal);
            ventas = "0";
            total = total + comisiones;
        }else{ // si no
            ventasCal.setText("Comisiones 10% de ventas: $0 No cumple meta");
            ventasCal.setBounds(20, 70, 300, 20);
            ventasCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            panel2.add(ventasCal);
            ventas = "0";
            }
        //Subsidio de transporte
        if (Integer.parseInt(salario) <= 2320000){ //si cumple con salario maximo
            subCal.setText("Subsidio de transporte: $" + subsidioTrans);
            subCal.setBounds(20, 90, 300, 20);
            subCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            panel2.add(subCal);
            total = total + subsidioTrans;
        }else{
            subsidioTrans = 0;
            subCal.setText("Subsidio de transporte: $" + subsidioTrans);
            subCal.setBounds(20, 90, 300, 20);
            subCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            panel2.add(subCal);            
        }
        totalCal.setText("Total a pagar: $" + total);
        totalCal.setBounds(20, 110, 300, 20);
        totalCal.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        totalCal.setForeground(Color.GREEN);
        panel2.add(totalCal);
        total = 0;
    }

    public void cajas() {
        nombreCaja.setBounds(130, 30, 220, 20);
        panel.add(nombreCaja);
        cedulaCaja.setBounds(130, 60, 220, 20);
        panel.add(cedulaCaja);
        salarioCaja.setBounds(130, 90, 220, 20);
        panel.add(salarioCaja);
        ventasCaja.setBounds(130, 120, 220, 20);
        panel.add(ventasCaja);
    }

    public void etiquetas() {
        nombre.setBounds(30, 30, 80, 20);
        nombre.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel.add(nombre);
        cedula.setBounds(30, 60, 80, 20);
        cedula.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel.add(cedula);
        salario.setBounds(30, 90, 80, 20);
        salario.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel.add(salario);
        ventas.setBounds(30, 120, 80, 20);
        ventas.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        panel.add(ventas);
    }

    public void botones() {
        boton.setBounds(90, 150, 200, 20);
        panel.add(boton);
    }

    public JTextField getNombreCaja() {
        return nombreCaja;
    }

    public void setNombreCaja(JTextField nombreCaja) {
        this.nombreCaja = nombreCaja;
    }

    public JTextField getCedulaCaja() {
        return cedulaCaja;
    }

    public void setCedulaCaja(JTextField cedulaCaja) {
        this.cedulaCaja = cedulaCaja;
    }

    public JPanel getPanel2() {
        return panel2;
    }

    public void setPanel2(JPanel panel2) {
        this.panel2 = panel2;
    }

    public JTextField getSalarioCaja() {
        return salarioCaja;
    }

    public void setSalarioCaja(JTextField salarioCaja) {
        this.salarioCaja = salarioCaja;
    }

    public JTextField getComisionesCaja() {
        return ventasCaja;
    }

    public void setComisionesCaja(JTextField comisionesCaja) {
        this.ventasCaja = comisionesCaja;
    }

    public JButton getBoton() {
        return boton;
    }

    public void setBoton(JButton boton) {
        this.boton = boton;
    }

    public JPanel getPanel() {
        return panel;
    }

    public void setPanel(JPanel panel) {
        this.panel = panel;
    }
}
