package contextualizacion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VistaPrincipal extends JFrame{
    JLabel etiqueta1 = new JLabel("Nombre");
    JLabel etiqueta2 = new JLabel("Cedula");
    JPanel panel = new JPanel();
    JTextField cajaNombre = new JTextField();
    JTextField cajaCedula = new JTextField();
    JButton boton1 = new JButton("Continuar");
    VistaSegunda vista2 = new VistaSegunda();
     
    public void iniciarVentana(){
        setSize(500, 200);
        setResizable(false);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Liquidacion trabajador");
        this.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBounds(0, 0, 500, 200);
        etiquetas();
        cajasTexto();
        botones();
        eventos();
    }
    
    public void eventos(){
        ActionListener accionContinuar = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                vista2.iniciarVentana();
                setVisible(false);
            }
        };
        boton1.addActionListener(accionContinuar);
    }

    public JButton getBoton1() {
        return boton1;
    }
    
    public void etiquetas(){
        panel.add(etiqueta1);
        etiqueta1.setBounds(70, 0, 100, 100);
        etiqueta2.setBounds(70, 40, 100, 100);
        panel.add(etiqueta2);
    }
    
    public void cajasTexto(){
        cajaNombre.setBounds(150, 40, 220, 20);
        panel.add(cajaNombre);
        cajaCedula.setBounds(150, 80, 220, 20);
        panel.add(cajaCedula);
    }
    
    public void botones(){
        boton1.setBounds(200, 120, 100, 20);
        panel.add(boton1);
    }

    public JTextField getCajaNombre() {
        return cajaNombre;
    }

    public JTextField getCajaCedula() {
        return cajaCedula;
    }
    
}
